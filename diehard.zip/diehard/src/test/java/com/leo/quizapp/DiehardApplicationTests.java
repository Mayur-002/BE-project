package com.leo.quizapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DiehardApplicationTests {

	@Test
	void contextLoads() {
	}

}
