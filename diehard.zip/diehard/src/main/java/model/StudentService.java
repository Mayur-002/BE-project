package model;

public interface StudentService {

}
